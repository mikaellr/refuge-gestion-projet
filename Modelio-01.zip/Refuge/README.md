Dossier de projet [Modelio](https://www.modelio.org/) "Refuge".

Ce sont donc les fichiers internes aux dossiers de projet du logiciel, et je crains fort qu'ils ne se prêtent que très mal à l'édition concurrente comme si c'était du code source...

Le dossier XMI contient une importation interne de la partie modéle dans un format d'échange entre logiciels UML ([XMI](https://fr.wikipedia.org/wiki/XML_Metadata_Interchange)).
